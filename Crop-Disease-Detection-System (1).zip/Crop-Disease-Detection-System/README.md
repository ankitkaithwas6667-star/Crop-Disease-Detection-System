# Crop Disease Detection System

## Project overview
A beginner-friendly Python project that takes a crop name and visible symptoms,
suggests a possible disease from a small rule-based knowledge guide, and stores
each check in an SQLite database.

## Important limitation
This is an educational, symptom-based prototype. It does **not** analyse leaf
photos and it does **not** provide a confirmed diagnosis. Symptoms can overlap
between diseases and nutrient or environmental problems. Confirm findings with
a qualified local agriculture expert before taking action.

## Crops included
- Tomato
- Potato
- Rice
- Wheat
- Maize
- Cotton

## Features
1. Check crop symptoms
2. Get a possible disease match and general suggestion
3. Save checks automatically in SQLite
4. View previous detection history

## Technology used
- Python 3
- SQLite (built into Python)
- Python IDLE

## Requirements
Python 3. No extra Python packages are required.

## How to run
1. Download or clone this repository.
2. Open `main.py` in Python IDLE.
3. Select **Run > Run Module** or press **F5**.
4. Enter `1` to check crop symptoms.
5. Enter a supported crop and describe its visible symptoms.
6. Enter `2` to view saved history, or `3` to exit.

The database file `crop_disease_records.db` is created automatically the first
time the program runs.

## Example test
- Menu choice: `1`
- Crop: `tomato`
- Symptoms: `brown spots on leaves`

Expected possible result: `Early Blight (possible)`

## Project files
- `main.py` — main Python program
- `README.md` — project documentation
- `requirements.txt` — package requirements
- `.gitignore` — files that should not be uploaded

## Future improvements
- Add leaf-image classification using a properly trained machine-learning model.
- Expand the crop and disease knowledge base with verified agricultural sources.
- Add a graphical user interface.
