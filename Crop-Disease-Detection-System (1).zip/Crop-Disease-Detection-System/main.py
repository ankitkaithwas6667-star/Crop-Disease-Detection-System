"""
Crop Disease Detection System
A beginner-friendly, symptom-based Python project.

Note:
This is an educational rule-based prototype. It suggests possible diseases
from the symptoms selected by the user; it does NOT diagnose a leaf image
or replace advice from an agricultural expert.
"""

import sqlite3
from datetime import datetime

DB_NAME = "crop_disease_records.db"

# Knowledge base: crop -> symptom keywords -> possible disease and advice
DISEASE_GUIDE = {
    "tomato": [
        {
            "keywords": ["brown spots", "dark spots", "yellow ring"],
            "disease": "Early Blight (possible)",
            "advice": "Remove badly affected leaves, avoid wetting foliage, "
                      "and ask a local agriculture expert about suitable treatment."
        },
        {
            "keywords": ["white powder", "powdery", "white patches"],
            "disease": "Powdery Mildew (possible)",
            "advice": "Improve air circulation, remove affected plant parts, "
                      "and seek locally approved disease-management advice."
        },
        {
            "keywords": ["yellow leaves", "wilting", "drooping"],
            "disease": "General stress or wilt (possible)",
            "advice": "Check soil moisture and drainage. Several problems can "
                      "cause these symptoms, so get the plant checked."
        }
    ],
    "potato": [
        {
            "keywords": ["dark patches", "water soaked", "rapid browning"],
            "disease": "Late Blight (possible)",
            "advice": "Separate affected plants where practical, avoid overhead "
                      "watering, and contact an agriculture expert promptly."
        },
        {
            "keywords": ["brown spots", "target rings", "concentric rings"],
            "disease": "Early Blight (possible)",
            "advice": "Remove affected leaves, keep foliage as dry as practical, "
                      "and ask about locally approved management."
        }
    ],
    "rice": [
        {
            "keywords": ["diamond spots", "spindle spots", "grey centre"],
            "disease": "Rice Blast (possible)",
            "advice": "Consult a local agriculture officer about resistant varieties "
                      "and suitable field management."
        },
        {
            "keywords": ["yellowing", "orange tips", "yellow orange"],
            "disease": "Possible nutrient issue or bacterial/other disease",
            "advice": "Check field conditions and seek an expert diagnosis before treatment."
        }
    ],
    "wheat": [
        {
            "keywords": ["orange pustules", "rust coloured", "orange powder"],
            "disease": "Wheat Rust (possible)",
            "advice": "Monitor the crop and contact an agriculture expert for "
                      "confirmation and locally recommended control."
        },
        {
            "keywords": ["white powder", "white coating"],
            "disease": "Powdery Mildew (possible)",
            "advice": "Improve field monitoring and ask an expert about suitable management."
        }
    ],
    "maize": [
        {
            "keywords": ["long grey spots", "long cigar spots", "grey lesions"],
            "disease": "Northern Corn Leaf Blight (possible)",
            "advice": "Remove crop debris where practical and ask about resistant "
                      "varieties and local disease-management options."
        },
        {
            "keywords": ["yellow stripes", "mosaic", "striped leaves"],
            "disease": "Possible viral or nutrient-related problem",
            "advice": "Check for insect activity and get an expert diagnosis."
        }
    ],
    "cotton": [
        {
            "keywords": ["angular spots", "water soaked spots", "leaf spots"],
            "disease": "Possible bacterial leaf spot",
            "advice": "Avoid handling wet plants, monitor spread, and consult a local "
                      "agriculture expert for confirmation."
        },
        {
            "keywords": ["yellow leaves", "wilting"],
            "disease": "Possible wilt or plant stress",
            "advice": "Check soil drainage and root health; seek expert confirmation."
        }
    ]
}


def create_database():
    """Create a table to save the user's checks."""
    connection = sqlite3.connect(DB_NAME)
    cursor = connection.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS checks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            check_date TEXT NOT NULL,
            crop TEXT NOT NULL,
            symptoms TEXT NOT NULL,
            result TEXT NOT NULL,
            advice TEXT NOT NULL
        )
    """)
    connection.commit()
    connection.close()


def detect_disease(crop, symptoms):
    """Match entered symptoms with the simple knowledge base."""
    crop = crop.strip().lower()
    symptoms_lower = symptoms.strip().lower()

    if crop not in DISEASE_GUIDE:
        return (
            "Crop not available in this demo",
            "Supported crops: tomato, potato, rice, wheat, maize and cotton. "
            "Please consult an agriculture expert for other crops."
        )

    for item in DISEASE_GUIDE[crop]:
        for keyword in item["keywords"]:
            if keyword in symptoms_lower:
                return item["disease"], item["advice"]

    return (
        "No clear match found",
        "The entered symptoms do not match this demo's guide. Try describing "
        "visible signs more clearly, or consult a local agriculture expert."
    )


def save_record(crop, symptoms, result, advice):
    """Save one detection check in SQLite."""
    connection = sqlite3.connect(DB_NAME)
    cursor = connection.cursor()
    cursor.execute("""
        INSERT INTO checks (check_date, crop, symptoms, result, advice)
        VALUES (?, ?, ?, ?, ?)
    """, (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
          crop, symptoms, result, advice))
    connection.commit()
    connection.close()


def view_history():
    """Display previously saved checks."""
    connection = sqlite3.connect(DB_NAME)
    cursor = connection.cursor()
    cursor.execute("""
        SELECT id, check_date, crop, symptoms, result
        FROM checks ORDER BY id DESC
    """)
    records = cursor.fetchall()
    connection.close()

    print("\n========== DETECTION HISTORY ==========")
    if not records:
        print("No records found.")
    else:
        for record in records:
            print("\nRecord ID:", record[0])
            print("Date:", record[1])
            print("Crop:", record[2].title())
            print("Symptoms:", record[3])
            print("Result:", record[4])
    print("=======================================\n")


def check_crop():
    """Take crop and symptoms from the user and show a possible result."""
    print("\nSupported crops: Tomato, Potato, Rice, Wheat, Maize, Cotton")
    crop = input("Enter crop name: ").strip()
    symptoms = input("Describe the visible symptoms: ").strip()

    if not crop or not symptoms:
        print("\nPlease enter both crop name and symptoms.\n")
        return

    result, advice = detect_disease(crop, symptoms)

    print("\n========== DETECTION RESULT ==========")
    print("Crop:", crop.title())
    print("Symptoms:", symptoms)
    print("Possible result:", result)
    print("Suggestion:", advice)
    print("\nImportant: This is only an educational suggestion, not a confirmed diagnosis.")
    print("======================================\n")

    save_record(crop, symptoms, result, advice)
    print("Your check has been saved successfully.\n")


def main():
    create_database()

    while True:
        print("======================================")
        print("       CROP DISEASE DETECTION SYSTEM")
        print("======================================")
        print("1. Check crop symptoms")
        print("2. View detection history")
        print("3. Exit")

        choice = input("Enter your choice (1-3): ").strip()

        if choice == "1":
            check_crop()
        elif choice == "2":
            view_history()
        elif choice == "3":
            print("\nThank you for using Crop Disease Detection System!")
            break
        else:
            print("\nInvalid choice. Please enter 1, 2 or 3.\n")


if __name__ == "__main__":
    main()
